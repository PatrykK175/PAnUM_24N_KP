package com.example.timer;

import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private LinearLayout stopwatchLayout, timerLayout;
    private TextView stopwatchDisplay;
    private EditText timerDisplay;

    private Button btnStartStopwatch, btnStopStopwatch, btnResetStopwatch;

    private Button btnStartTimer, btnStopTimer, btnResetTimer;

    private Handler stopwatchHandler = new Handler();
    private long stopwatchStartTime = 0L;
    private long stopwatchElapsedTime = 0L;
    private boolean isStopwatchRunning = false;

    private Handler timerHandler = new Handler();
    private long timerRemainingTime = 0L;
    private boolean isTimerRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        stopwatchLayout = findViewById(R.id.stopwatch_layout);
        timerLayout = findViewById(R.id.timer_layout);
        stopwatchDisplay = findViewById(R.id.stopwatch_display);
        timerDisplay = findViewById(R.id.timer_display);

        btnStartStopwatch = findViewById(R.id.btn_start);
        btnStopStopwatch = findViewById(R.id.btn_stop);
        btnResetStopwatch = findViewById(R.id.btn_reset);

        btnStartTimer = findViewById(R.id.timer_btn_start);
        btnStopTimer = findViewById(R.id.timer_btn_stop);
        btnResetTimer = findViewById(R.id.timer_btn_reset);

        btnStartStopwatch.setOnClickListener(v -> startStopwatch());
        btnStopStopwatch.setOnClickListener(v -> stopStopwatch());
        btnResetStopwatch.setOnClickListener(v -> resetStopwatch());

        btnStartTimer.setOnClickListener(v -> startTimer());
        btnStopTimer.setOnClickListener(v -> stopTimer());
        btnResetTimer.setOnClickListener(v -> resetTimer());
    }

    private void startStopwatch() {
        if (!isStopwatchRunning) {
            stopwatchStartTime = System.currentTimeMillis() - stopwatchElapsedTime; // Kontynuacja od poprzedniego czasu
            isStopwatchRunning = true;
            stopwatchHandler.post(updateStopwatch);
        }
    }

    private void stopStopwatch() {
        isStopwatchRunning = false;
        stopwatchHandler.removeCallbacks(updateStopwatch);
    }

    private void resetStopwatch() {
        stopStopwatch();
        stopwatchElapsedTime = 0L;
        stopwatchDisplay.setText("00:00.00");
    }

    private Runnable updateStopwatch = new Runnable() {
        @Override
        public void run() {
            if (isStopwatchRunning) {
                long currentTime = System.currentTimeMillis();
                stopwatchElapsedTime = currentTime - stopwatchStartTime;

                int totalSeconds = (int) (stopwatchElapsedTime / 1000);
                int minutes = totalSeconds / 60;
                int seconds = totalSeconds % 60;
                int hundredths = (int) (stopwatchElapsedTime % 1000) / 10;

                stopwatchDisplay.setText(String.format("%02d:%02d.%02d", minutes, seconds, hundredths));

                stopwatchHandler.postDelayed(this, 10);
            }
        }
    };

    private void startTimer() {
        if (!isTimerRunning) {
            String inputTime = timerDisplay.getText().toString();
            if (!TextUtils.isEmpty(inputTime)) {
                timerRemainingTime = parseTimeToMillis(inputTime);
                if (timerRemainingTime > 0) {
                    isTimerRunning = true;
                    timerHandler.post(updateTimer);
                }
            }
        }
    }

    private void stopTimer() {
        isTimerRunning = false;
        timerHandler.removeCallbacks(updateTimer);
    }

    private void resetTimer() {
        stopTimer();
        timerRemainingTime = 0L;
        timerDisplay.setText("00:00:00.0");
    }

    private Runnable updateTimer = new Runnable() {
        @Override
        public void run() {
            if (isTimerRunning) {
                if (timerRemainingTime > 0) {
                    timerRemainingTime -= 100;

                    int totalSeconds = (int) (timerRemainingTime / 1000);
                    int hours = totalSeconds / 3600;
                    int minutes = (totalSeconds % 3600) / 60;
                    int seconds = totalSeconds % 60;
                    int tenths = (int) (timerRemainingTime % 1000) / 100;

                    timerDisplay.setText(String.format("%02d:%02d:%02d.%d", hours, minutes, seconds, tenths));

                    timerHandler.postDelayed(this, 100);
                } else {
                    isTimerRunning = false;
                    timerDisplay.setText("00:00:00.0");
                }
            }
        }
    };

    private long parseTimeToMillis(String time) {
        try {
            String[] parts = time.split(":");
            int hours = Integer.parseInt(parts[0]);
            int minutes = Integer.parseInt(parts[1]);
            String[] secondsAndTenths = parts[2].split("\\.");
            int seconds = Integer.parseInt(secondsAndTenths[0]);
            int tenths = secondsAndTenths.length > 1 ? Integer.parseInt(secondsAndTenths[1]) : 0;

            return (hours * 3600 + minutes * 60 + seconds) * 1000 + tenths * 100;
        } catch (Exception e) {
            e.printStackTrace();
            return 0L;
        }
    }
}