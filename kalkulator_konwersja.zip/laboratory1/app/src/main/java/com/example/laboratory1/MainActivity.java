package com.example.laboratory1;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText arabicInput = findViewById(R.id.arabic_input);
        EditText romanInput = findViewById(R.id.roman_input);
        TextView resultText = findViewById(R.id.result_text);

        Button button1 = findViewById(R.id.arabic_button_1);
        Button button2 = findViewById(R.id.arabic_button_2);
        Button button3 = findViewById(R.id.arabic_button_3);
        Button button4 = findViewById(R.id.arabic_button_4);
        Button button5 = findViewById(R.id.arabic_button_5);
        Button button6 = findViewById(R.id.arabic_button_6);
        Button button7 = findViewById(R.id.arabic_button_7);
        Button button8 = findViewById(R.id.arabic_button_8);
        Button button9 = findViewById(R.id.arabic_button_9);
        Button button0 = findViewById(R.id.arabic_button_0);
        Button clearButton = findViewById(R.id.arabic_button_clear);
        Button clearLastButton = findViewById(R.id.arabic_button_clear_last);

        View.OnClickListener numberClickListener = new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                Button clickedButton = (Button) v;
                String currentText = arabicInput.getText().toString();
                arabicInput.setText(currentText + clickedButton.getText().toString());
            }
        };

        clearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                arabicInput.setText("");
            }
        });

        clearLastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentText = arabicInput.getText().toString();
                if (!currentText.isEmpty()) {
                    arabicInput.setText(currentText.substring(0, currentText.length() - 1));
                }
            }
        });

        button1.setOnClickListener(numberClickListener);
        button2.setOnClickListener(numberClickListener);
        button3.setOnClickListener(numberClickListener);
        button4.setOnClickListener(numberClickListener);
        button5.setOnClickListener(numberClickListener);
        button6.setOnClickListener(numberClickListener);
        button7.setOnClickListener(numberClickListener);
        button8.setOnClickListener(numberClickListener);
        button9.setOnClickListener(numberClickListener);
        button0.setOnClickListener(numberClickListener);

        Button rbuttonI = findViewById(R.id.roman_button_I);
        Button rbuttonV = findViewById(R.id.roman_button_V);
        Button rbuttonX = findViewById(R.id.roman_button_X);
        Button rbuttonL = findViewById(R.id.roman_button_L);
        Button rbuttonC = findViewById(R.id.roman_button_C);
        Button rbuttonD = findViewById(R.id.roman_button_D);
        Button rbuttonM = findViewById(R.id.roman_button_M);
        Button rclearButton = findViewById(R.id.roman_button_clear);
        Button rclearLastButton = findViewById(R.id.roman_button_clear_last);

        View.OnClickListener rNumberClickListener = new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                Button clickedButton = (Button) v;
                String currentText = romanInput.getText().toString();
                romanInput.setText(currentText + clickedButton.getText().toString());
            }
        };

        rclearButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                romanInput.setText("");
            }
        });

        rclearLastButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String currentText = romanInput.getText().toString();
                if (!currentText.isEmpty()) {
                    romanInput.setText(currentText.substring(0, currentText.length() - 1));
                }
            }
        });

        rbuttonI.setOnClickListener(rNumberClickListener);
        rbuttonV.setOnClickListener(rNumberClickListener);
        rbuttonX.setOnClickListener(rNumberClickListener);
        rbuttonL.setOnClickListener(rNumberClickListener);
        rbuttonC.setOnClickListener(rNumberClickListener);
        rbuttonD.setOnClickListener(rNumberClickListener);
        rbuttonM.setOnClickListener(rNumberClickListener);

        Button convertToRomanButton = findViewById(R.id.convert_to_roman);
        Button convertToArabicButton = findViewById(R.id.convert_to_arabic);

        convertToRomanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String arabicNumberStr = arabicInput.getText().toString();
                if (!TextUtils.isEmpty(arabicNumberStr)) {
                    int arabicNumber = Integer.parseInt(arabicNumberStr);
                    String romanResult = arabicToRoman(arabicNumber);
                    resultText.setText("Wynik: " + romanResult);
                } else {
                    resultText.setText("Wprowadź liczbę arabską");
                }
            }
        });

        convertToArabicButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String romanNumber = romanInput.getText().toString();
                if (!TextUtils.isEmpty(romanNumber)) {
                    int arabicResult = romanToArabic(romanNumber);
                    if (arabicResult != -1) {
                        resultText.setText("Wynik: " + arabicResult);
                    } else {
                        resultText.setText("Nieprawidłowa liczba rzymska");
                    }
                } else {
                    resultText.setText("Wprowadź liczbę rzymską");
                }
            }
        });
    }

    private String arabicToRoman(int number) {
        if (number <= 0 || number > 3999) {
            return "Nieprawidłowa liczba";
        }
        StringBuilder result = new StringBuilder();
        int[] values = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};
        String[] symbols = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
        for (int i = 0; i < values.length; i++) {
            while (number >= values[i]) {
                result.append(symbols[i]);
                number -= values[i];
            }
        }
        return result.toString();
    }

    private int romanToArabic(String roman) {
        if (roman == null || roman.isEmpty()) {
            return -1;
        }
        int[] values = {1000, 500, 100, 50, 10, 5, 1};
        char[] symbols = {'M', 'D', 'C', 'L', 'X', 'V', 'I'};
        int result = 0;
        int prevValue = 0;
        for (int i = roman.length() - 1; i >= 0; i--) {
            char c = roman.charAt(i);
            int value = 0;
            for (int j = 0; j < symbols.length; j++) {
                if (c == symbols[j]) {
                    value = values[j];
                    break;
                }
            }
            if (value == 0) {
                return -1;
            }
            if (value < prevValue) {
                result -= value;
            } else {
                result += value;
            }
            prevValue = value;
        }
        return result;
    }
}