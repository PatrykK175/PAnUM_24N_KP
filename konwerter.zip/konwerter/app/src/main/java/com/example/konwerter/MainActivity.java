package com.example.konwerter;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private TextView outputValue;
    private Spinner conversionTypeSpinner;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        outputValue = findViewById(R.id.outputValue);
        conversionTypeSpinner = findViewById(R.id.conversionTypeSpinner);
        convertButton = findViewById(R.id.convertButton);

        String[] conversionTypes = {
                "Złotówki na Euro",
                "Centymetry na Cal",
                "Celsjusz na Fahrenheit",
                "Kilometry na Mile",
                "Mile na Kilometry"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, conversionTypes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conversionTypeSpinner.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String input = inputValue.getText().toString();

        if (input.isEmpty()) {
            Toast.makeText(this, "Wpisz wartość do konwersji", Toast.LENGTH_SHORT).show();
            return;
        }

        double inputValueDouble = Double.parseDouble(input);
        String selectedConversion = conversionTypeSpinner.getSelectedItem().toString();
        double result = 0;

        switch (selectedConversion) {
            case "Złotówki na Euro":
                result = inputValueDouble * 0.22;
                break;
            case "Centymetry na Cal":
                result = inputValueDouble * 0.393701;
                break;
            case "Celsjusz na Fahrenheit":
                result = (inputValueDouble * 9 / 5) + 32;
                break;
            case "Kilometry na Mile":
                result = inputValueDouble * 0.621371;
                break;
            case "Mile na Kilometry":
                result = inputValueDouble / 0.621371;
                break;
        }

        outputValue.setText(String.format("Wynik: %.2f", result));
    }
}